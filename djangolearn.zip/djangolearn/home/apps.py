from django.apps import AppConfig


class HomeConfig(AppConfig):
    name = 'home'
